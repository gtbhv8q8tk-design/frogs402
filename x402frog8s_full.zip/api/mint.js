require('dotenv').config();
const fs = require('fs');
const path = require('path');

module.exports = async (req, res) => {
  try {
    if (req.method !== 'GET') {
      res.setHeader('Allow', 'GET');
      return res.status(405).json({ error: 'Method not allowed' });
    }

    const offersPath = path.join(__dirname, '..', 'data', 'offers.json');
    let offers = [];
    try { offers = JSON.parse(fs.readFileSync(offersPath,'utf8')); } catch(e) {}
    const id = req.query.id || '1';
    const offer = offers.find(o => o.id === String(id)) || {
      id: '1',
      title: 'x402frog8s #1',
      price_usdc: 1,
      tokenId: 1,
      metadata: 'https://ipfs.io/ipfs/bafybeiabfisrq64kdbutc4ysjrgfjr3e56ggj3icqfnd5zuliuu3gmz4ti/1.json'
    };

    const baseUrl = process.env.PUBLIC_URL || (`https://${req.headers.host}`);

    const payload = {
      amount: offer.price_usdc,
      currency: 'USDC',
      tokenAddress: process.env.USDC_ADDRESS || '0x833589fCD6eDb6E08f4c7C32D4f71b54B268F8c7',
      receiver: process.env.TREASURY || '0x1DEf6d9E7ba7256dF17d01Bf7D8FA62d82A27Fc4',
      chainId: 8453,
      resource: `${baseUrl}/api/mint?id=${offer.id}`,
      name: offer.title,
      description: `Mint ${offer.title} (tokenId ${offer.tokenId})`,
      metadataURI: offer.metadata
    };

    return res.status(402).json(payload);
  } catch (err) {
    console.error('mint error', err);
    return res.status(500).json({ error: String(err) });
  }
};
