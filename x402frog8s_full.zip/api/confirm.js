require('dotenv').config();
const { ethers } = require('ethers');
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const uuid = require('uuid');

const ERC20_ABI = [
  "event Transfer(address indexed from, address indexed to, uint256 value)",
  "function decimals() view returns (uint8)"
];

async function sendTelegram(chatId, text) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token || !chatId) return;
  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  try {
    await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML' }) });
  } catch (e) { console.error('tg send error', e); }
}

module.exports = async (req, res) => {
  try {
    if (req.method !== 'POST') {
      res.setHeader('Allow', 'POST');
      return res.status(405).json({ error: 'Method not allowed' });
    }
    const { txHash, id, buyer, buyerTelegram } = req.body;
    if (!txHash || !id || !buyer) return res.status(400).json({ error: 'txHash, id, buyer required' });

    const provider = new ethers.providers.JsonRpcProvider(process.env.BASE_RPC || 'https://mainnet.base.org');
    const receipt = await provider.getTransactionReceipt(txHash);
    if (!receipt || !receipt.logs) return res.status(400).json({ error: 'tx not found or pending' });

    const USDC_ADDRESS = (process.env.USDC_ADDRESS || '0x833589fCD6eDb6E08f4c7C32D4f71b54B268F8c7').toLowerCase();
    const TREASURY = (process.env.TREASURY || '0x1DEf6d9E7ba7256dF17d01Bf7D8FA62d82A27Fc4').toLowerCase();
    const iface = new ethers.utils.Interface(ERC20_ABI);
    const PRICE_USDC = ethers.BigNumber.from(1).mul(ethers.BigNumber.from(10).pow(6));

    let found = false;
    for (const log of receipt.logs) {
      if (log.address.toLowerCase() === USDC_ADDRESS) {
        try {
          const parsed = iface.parseLog(log);
          if (parsed && parsed.name === 'Transfer') {
            const to = parsed.args[1];
            const value = parsed.args[2];
            if (to && to.toLowerCase() === TREASURY && value.gte(PRICE_USDC)) {
              found = true;
              break;
            }
          }
        } catch (e) { }
      }
    }
    if (!found) return res.status(402).json({ error: 'payment not detected or insufficient' });

    // immediate notification
    const adminTg = process.env.ADMIN_TELEGRAM_ID;
    const immediateMsg = `Payment received for offer ${id}. buyer=${buyer} tx=${txHash}`;
    if (buyerTelegram) await sendTelegram(buyerTelegram, 'Payment received — ваш NFT буде запитано незабаром.');
    if (adminTg) await sendTelegram(adminTg, immediateMsg);

    // mint
    const COLLECTION_ADDRESS = process.env.COLLECTION_ADDRESS;
    if (!COLLECTION_ADDRESS) return res.status(500).json({ error: 'COLLECTION_ADDRESS not configured' });

    const signer = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
    const collection = new ethers.Contract(COLLECTION_ADDRESS, [ "function mintFor(address to, uint256 id, uint256 amount, bytes data) external" ], signer);

    const offersPath = path.join(__dirname, '..', 'data', 'offers.json');
    let offers = [];
    try { offers = JSON.parse(fs.readFileSync(offersPath,'utf8')); } catch(e){}
    const offer = offers.find(o=>String(o.id) === String(id)) || { tokenId: Number(id) };

    const tx = await collection.mintFor(buyer, Number(offer.tokenId || id), 1, "0x");
    const txr = await tx.wait();

    // final notification
    const finalMsg = `Ваш NFT було замінтено. Mint tx: ${txr.transactionHash}`;
    if (buyerTelegram) await sendTelegram(buyerTelegram, finalMsg);
    if (adminTg) await sendTelegram(adminTg, `Minted for ${buyer}: ${txr.transactionHash}`);

    // record sale
    const salesPath = path.join(__dirname, '..', 'data', 'sales.json');
    let sales = [];
    if (fs.existsSync(salesPath)) sales = JSON.parse(fs.readFileSync(salesPath,'utf8'));
    const sale = { id: uuid.v4(), offerId: id, buyer, paymentTx: txHash, mintTx: txr.transactionHash, time: Date.now() };
    sales.push(sale);
    fs.writeFileSync(salesPath, JSON.stringify(sales, null, 2));

    return res.json({ success: true, mintTx: txr.transactionHash });
  } catch (err) {
    console.error('confirm error', err);
    return res.status(500).json({ error: String(err) });
  }
};
