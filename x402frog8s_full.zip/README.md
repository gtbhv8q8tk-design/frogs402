x402frog8s — full Vercel project (frontend + x402 seller)

How to use:
1. Push this repo to GitHub and import to Vercel.
2. Set environment variables in Vercel (see .env.example):
   - PRIVATE_KEY, COLLECTION_ADDRESS (must be set)
   - optional: TELEGRAM_BOT_TOKEN and ADMIN_TELEGRAM_ID for notifications
3. Deploy. Open the app root (e.g. https://your-app.vercel.app) and click 'Get Payment Info'.
4. Send 1 USDC (on Base) to TREASURY address shown in payload. Then paste txHash and buyer address in the form and submit.
5. The server will verify payment, notify via Telegram (if configured), mint the NFT and return mintTx.

Security notes:
- PRIVATE_KEY must be stored as a secret in Vercel; never commit it.
- For production, add confirmations, replay protection and rate limiting.
